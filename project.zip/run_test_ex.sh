python main_ex.py $1
