#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import numpy as np
from system import runSystem


def main(s):
    config_folder = 'config'
    # Get config from file mode_*.txt
    with open(os.path.join(config_folder, 'mode_'+s+'.txt')) as fd:
        mode = fd.readline().strip()
    # Get config from file para_*.txt
    para = np.loadtxt(os.path.join(config_folder, 'para_'+s+'.txt'))
    # Get config from file interarrival_*.txt
    interarrival_times = np.loadtxt(os.path.join(
        config_folder, 'interarrival_'+s+'.txt'))
    # Get config from file service_*.txt
    ground_service_times = np.loadtxt(os.path.join(
        config_folder, 'service_'+s+'.txt'))
    print(mode, para, interarrival_times, ground_service_times, "\n\n")
    # Running system
    s1_dep, s2_dep, s3_dep = runSystem(
        mode, para, interarrival_times, ground_service_times, 0)
    response_times = 0
    out_folder = 'output'

    # write dep file for Server 1
    out_file = os.path.join(out_folder, 's1_dep_'+s+'.txt')
    with open(out_file, 'w') as dep:
        for req in s1_dep:
            arrival_time, departure_time = req
            # Sum response_time
            response_times += departure_time-arrival_time
            dep.writelines('{:.4f} {:.4f}\n'.format(
                arrival_time, departure_time))
    # write dep file for Server 2
    out_file = os.path.join(out_folder, 's2_dep_'+s+'.txt')
    with open(out_file, 'w') as dep:
        for req in s2_dep:
            arrival_time, departure_time = req
            # Sum response_time
            response_times += departure_time-arrival_time
            dep.writelines('{:.4f} {:.4f}\n'.format(
                arrival_time, departure_time))
    # write dep file for Server 3
    out_file = os.path.join(out_folder, 's3_dep_'+s+'.txt')
    with open(out_file, 'w') as dep:
        for req in s3_dep:
            arrival_time, departure_time = req
            # Sum response_time
            response_times += departure_time-arrival_time
            dep.writelines('{:.4f} {:.4f}\n'.format(
                arrival_time, departure_time))

    # write mean response time to file mrt
    out_file = os.path.join(out_folder, 'mrt_'+s+'.txt')
    with open(out_file, 'w') as mrt:
        # Calculate mean response time
        mean_response_time = round(
            response_times/(len(s1_dep)+len(s2_dep)+len(s3_dep)), 4)
        mrt.writelines('{:.4f}\n'.format(mean_response_time))


if __name__ == "__main__":
    main(sys.argv[1])
