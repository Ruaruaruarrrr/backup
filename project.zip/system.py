import numpy as np
import random
import os


class Server:
    def __init__(self, server_id, processing_rate):
        # Set server id (1 or 2 or 3)
        self.id = server_id
        # Init processing rate
        self.f = processing_rate
        # Init waiting queue
        self.queue = []
        # Curr request that being processing
        self.curr = None
        # Count num of requests in server
        self.n = 0
        # Time that all requests in the Server will finish
        self.server_time_end = 0
        self.tag()

    # Add new incoming requests that dispatched to this server
    def addRequest(self, curr_time, service_time):
        # Update finish time
        if self.server_time_end == 0:
            # For first request
            self.server_time_end = round(curr_time + service_time/self.f, 4)
        else:
            # curr_time may greater than the server_time_end setted before
            self.server_time_end = round(max(
                curr_time, self.server_time_end) + service_time/self.f, 4)
        if str(service_time/self.f)[::-1].find('.') > 4:
            service_time = round(service_time/self.f, 4)
        # Requet is a tuple of (arrival time, service time)
        request = (curr_time, self.server_time_end, service_time)
        # Check if server has current request being processing
        if self.curr != None:
            # Add to the queue
            self.queue += [request]
        else:
            # Server can handle this request directly
            self.curr = request
        # Update Counter
        self.n += 1
        return self.server_time_end

    # Check if current request is finished
    def handleRequest(self, curr_time):
        # Has curr request check if it's finished
        if self.curr != None:
            arrival_time, finish_time, _ = self.curr
            # print("in", self.id, curr_time, arrival_time, finish_time)
            if curr_time == finish_time:
                print("Event type: Depart", 'Server', str(self.id))
                # print("finished request in Server "+str(self.id) + "  (" + str(arrival_time) +
                #       ", " + str(finish_time) + ")  len(queue):", len(self.queue))
                # Check if queue is not empty
                if len(self.queue) > 0:
                    # Get first came in request in queue
                    self.curr = self.queue.pop(0)
                else:
                    # Set Server idle
                    self.curr = None
                # Update Counter
                self.n -= 1
                return (arrival_time, finish_time)
        return None

    # Get num of request in the server
    def getN(self):
        return self.n

    def tag(self):
        print("Creating the Server", self.id)


# The load balancing algorithm
def load_balancing_alg(version: int, S1: Server, S2: Server, S3: Server, d, f, curr_time, service_time):
    ns = min(S1.getN(), S2.getN())
    # Server 3 is idle
    if S3.getN() == 0:
        # dispach request to Server 3
        request_finish_time = S3.addRequest(curr_time, service_time)
    # At least one slow server is idle or
    # at least one slow server has far fewer jobs than the fast server
    # Algorithm 1 or Algorithm 2
    elif (version == 1 and (ns == 0 or ns <= S3.getN()-d)) or (version == 2 and (ns == 0 or ns <= (S3.getN()/f)-d)):
        # Server 1 has the least num of requests than Server 2
        if S1.getN() == ns:
            # dispach request to Server 1
            request_finish_time = S1.addRequest(curr_time, service_time)
        # Server 2 has the least num of requests than Server 1
        else:
            # dispach request to Server 2
            request_finish_time = S2.addRequest(curr_time, service_time)
    else:
        # dispach request to Server 3
        request_finish_time = S3.addRequest(curr_time, service_time)

    print("Event type: Arrival")
    return request_finish_time


# Generate 2 times for random mode
def generateTimes(lambda_, a_2l, a_2u, alph, beta):
    # Generate inter-arrival time
    a_1_k = np.random.exponential(scale=1/lambda_, size=None)
    a_2_k = np.random.uniform(low=a_2l, high=a_2u, size=None)
    a_k = a_1_k*a_2_k
    # Generate service time
    gamma = (beta-1)/(alph**(1-beta))
    service_time = alph
    # Must not equal alph
    while service_time == alph:
        # Get G(t) from [0,1]
        Gt = random.random()
        # Find the reverse
        service_time = ((Gt*(1-beta)/gamma) + (alph**(1-beta))) ** (1/(1-beta))
    # print("generated:", (round(a_k, 4), round(service_time, 4)))
    return (round(a_k, 4), round(service_time, 4))


# Get finished requests at certain time and store it
def getFinishedReq(curr_time, S, index, finished_requests):
    # Get requests that finished in this time point
    finished_request = True
    while finished_request:
        finished_request = S.handleRequest(curr_time)
        if finished_request != None:
            finished_requests[index] += [finished_request]


# Print log
def server_log(S, server_label):
    if S.curr != None:
        print("Server "+str(server_label)+":", 'Busy', S.curr[1])
        if S.queue == []:
            print("         ", "_")
        else:
            print("         ", [(arrival_time, service_time)
                                for (arrival_time, _, service_time) in S.queue])
    else:
        print("Server "+str(server_label)+":", 'Idle', "oo")
        print("         ", "_")


# Write to files
def writeToFile(l, out_file):
    out_file = os.path.join('supp/', out_file)
    with open(out_file, 'w') as rep:
        for i in l:
            rep.writelines(str(i)+'\n')


# Construct and run system
def runSystem(mode, para, interarrival_times, ground_service_times, repeatFlag):
    # Extract data from loaded variables
    if mode == 'trace':
        f, algorithm_version, d = para
        print(f, algorithm_version, d)
    elif mode == 'random':
        f, algorithm_version, d, time_end = para
        alph, beta = ground_service_times
        lambda_, a_2l, a_2u = interarrival_times
        print(f, algorithm_version, d, time_end,
              alph, beta, lambda_, a_2l, a_2u)
    # Create timeline and requests list for 'trace' mode
    timeLine = []
    requests = {}

    if mode == 'trace':
        curr = 0
        for i in range(len(interarrival_times)):
            curr += interarrival_times[i]
            # Add arrival time to timeLine
            timeLine += [round(curr, 4)]
            requests[round(curr, 4)] = ground_service_times[i]
    elif mode == 'random':
        # Init lists for reproducible in random mode
        interarrival_times_reproducible = []
        service_times_reproducible = []
        # Generate first request
        interarrival_time, ground_service_time = generateTimes(
            lambda_, a_2l, a_2u, alph, beta)
        # add to list for reproducting
        if repeatFlag == 1:
            interarrival_times_reproducible += [interarrival_time]
            service_times_reproducible += [ground_service_time]
        # Add arrival time to timeLine
        timeLine += [interarrival_time]
        # Map arrival time with corresponding sercvice time
        requests[interarrival_time] = ground_service_time
    print(sorted(timeLine), "\n\n")
    print(requests, "\n\n")

    # Create servers
    S1 = Server(1, 1)
    S2 = Server(2, 1)
    S3 = Server(3, f)
    # Start system
    finished_requests = [[], [], []]
    # Store lastest request arrival time
    lastest_arrival_time = timeLine[-1]
    while timeLine:
        # Get current time
        curr_time = timeLine.pop(0)
        print("======================")
        print("Mastar clock:", curr_time)

        # Ramdom mode stop flag
        if mode == 'random' and curr_time > time_end:
            break

        # Get requests that finished at this time point
        getFinishedReq(curr_time, S1, 0, finished_requests)
        getFinishedReq(curr_time, S2, 1, finished_requests)
        getFinishedReq(curr_time, S3, 2, finished_requests)

        # A request coming
        if curr_time in requests:
            # Apply load_balancing algrithm
            request_finish_time = load_balancing_alg(algorithm_version, S1, S2, S3,
                                                     d, f, curr_time, requests[curr_time])

            # Add finish time to time line, except this request has 0 sercive time
            if request_finish_time not in timeLine and request_finish_time != curr_time:
                # Add finish time to timeLine
                timeLine += [request_finish_time]
            # print(curr_time, request_finish_time, requests[curr_time])

            # Generate new request for random mode
            if mode == 'random':
                # Generate first request
                interarrival_time, ground_service_time = generateTimes(
                    lambda_, a_2l, a_2u, alph, beta)
                # add to list for reproducting
                if repeatFlag == 1:
                    interarrival_times_reproducible += [interarrival_time]
                    service_times_reproducible += [ground_service_time]
                # Update lastest request arrival time
                lastest_arrival_time = round(
                    lastest_arrival_time + interarrival_time, 4)
                # Add arrival time to timeLine
                timeLine += [lastest_arrival_time]
                # Map arrival time with corresponding sercvice time
                requests[lastest_arrival_time] = ground_service_time
        # some prints
        for k in sorted(requests.keys()):
            if k > curr_time:
                break
        print("Next arrival time:", k)
        server_log(S1, "1")
        server_log(S2, "2")
        server_log(S3, "3")

        # Sort timeLine
        timeLine = sorted(timeLine)
    # Write to files for reproducible
    if mode == 'random' and repeatFlag == 1:
        print(interarrival_times_reproducible[10:])
        print(service_times_reproducible[10:])
        writeToFile(interarrival_times_reproducible,
                    'interarrival_reproducible.txt')
        writeToFile(service_times_reproducible,
                    'service_reproducible.txt')
    print("\n>>>>>>debugging....\n")
    print("Show queues in each servers:\n", S1.queue,
          "\n", S2.queue, "\n", S3.queue, "\n")
    # print(finished_requests)
    return finished_requests
