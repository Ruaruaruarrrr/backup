from main_ex import main
import matplotlib.pyplot as plt
import numpy as np
from numpy import arange
import random
import os
import sys
from numpy import arange
from system import runSystem


def configDesignProblem(alg, end_time, d, test_index):
    out_dir = "config"
    f = 1.5
    lammda_ = 6.1
    a_2l = 0.8
    a_2u = 1.1
    alph = 0.2
    beta = 3.5

    # config\n",
    out_file = os.path.join(out_dir, 'mode_'+str(test_index)+'.txt')
    with open(out_file, 'w') as fd:
        fd.writelines('random')

    out_file = os.path.join(out_dir, 'para_'+str(test_index)+'.txt')
    with open(out_file, 'w') as fd:
        fd.writelines(str(f)+'\n'+str(alg)+'\n'+str(d)+'\n'+str(end_time)+'\n')

    out_file = os.path.join(out_dir, 'interarrival_'+str(test_index)+'.txt')
    with open(out_file, 'w') as fd:
        fd.writelines(str(lammda_)+'\n'+str(a_2l)+'\n'+str(a_2u)+'\n')

    out_file = os.path.join(out_dir, 'service_'+str(test_index)+'.txt')
    with open(out_file, 'w') as fd:
        fd.writelines(str(alph)+'\n'+str(beta)+'\n')


def changeEndTimes(alg, end_time, d, test_index):
    f = 1.5
    out_dir = "config"
    out_file = os.path.join(out_dir, 'para_'+str(test_index)+'.txt')
    with open(out_file, 'w') as fd:
        fd.writelines(str(f)+'\n'+str(alg)+'\n'+str(d)+'\n'+str(end_time)+'\n')


def getMeanRes(test_index):
    return np.loadtxt(os.path.join('output', 'mrt_'+str(test_index)+'.txt'))


def findBestEndTime(test_index, runs):
    configDesignProblem(1, 1, 1, test_index)
    end_times = [1000, 5000, 10000]
    mrts = []
    for end_time in end_times:
        mrt = []
        for r in range(runs):
            changeEndTimes(1, end_time, 2, test_index)
            # must config first
            main(test_index)
            mrt += [getMeanRes(test_index)]
        mrts += [mrt]
        with open("supp/means_"+str(end_time)+".txt", 'w') as fd:
            for m in mrt:
                fd.writelines(str(m)+'\n')
    print(mrts)


def findBestD(time_end):
    out_dir = "config"
    f = 1.5
    lambda_ = 6.1
    a_2l = 0.8
    a_2u = 1.1
    alph = 0.2
    beta = 3.5
    v1_means = []
    v2_means = []
    for d in arange(1.1, 3, 0.1):
        # V1
        (s1, s2, s3) = runSystem('random', (f, 1, d, time_end),
                                 (lambda_, a_2l, a_2u), (alph, beta), 0)
        v1data = s1+s2+s3
        v1data = v1data[3000:]
        response_times = []
        for req in v1data:
            arrival_time, departure_time = req
            response_times += [departure_time-arrival_time]
        mean_response_time = round(sum(response_times)/len(v1data), 4)
        v1_means += [mean_response_time]

        # V2
        (s1, s2, s3) = runSystem('random', (f, 2, d, time_end),
                                 (lambda_, a_2l, a_2u), (alph, beta), 0)
        v2data = s1+s2+s3
        v2data = v2data[3000:]
        response_times = []
        for req in v2data:
            arrival_time, departure_time = req
            response_times += [departure_time-arrival_time]
        mean_response_time = round(sum(response_times)/len(v2data), 4)
        v2_means += [mean_response_time]

    print("means of v1:\n", v1_means, "\n")
    print("means of v2:\n", v2_means, "\n")
    return (v1_means, v2_means)


def do_find_best_d():
    test_index = '10'
    runs = 2
    end_time = 10000
    # findBestEndTime(test_index, runs)
    # do 8 runs
    res = []
    for _ in range(runs):
        res += [findBestD(end_time)]
    print(res)


def version_compares(runs, time_end):
    f = 1.5
    lambda_ = 6.1
    a_2l = 0.8
    a_2u = 1.1
    alph = 0.2
    beta = 3.5
    d = 1.5
    v1_means = []
    v2_means = []
    for _ in range(runs):
        # V1
        (s1, s2, s3) = runSystem('random', (f, 1, d, time_end),
                                 (lambda_, a_2l, a_2u), (alph, beta), 1)
        v1data = s1+s2+s3
        # v1data = v1data[3000:]
        print(v1data)

        response_times = []
        for req in v1data:
            arrival_time, departure_time = req
            response_times += [departure_time-arrival_time]
        mean_response_time = round(sum(response_times)/len(v1data), 4)
        v1_means += [mean_response_time]

        # Get config from file interarrival_*.txt
        interarrival_times = np.loadtxt('supp/interarrival_reproducible.txt')
        # Get config from file service_*.txt
        ground_service_times = np.loadtxt('supp/service_reproducible.txt')
        print("\n\n", interarrival_times[10:],
              ground_service_times[10:], "\n\n")
        # V2
        (s1, s2, s3) = runSystem('trace', (f, 2, d),
                                 interarrival_times,  ground_service_times, 0)
        v2data = s1+s2+s3
        # v2data = v2data[3000:]
        response_times = []
        for req in v2data:
            arrival_time, departure_time = req
            response_times += [departure_time-arrival_time]
        mean_response_time = round(sum(response_times)/len(v2data), 4)
        v2_means += [mean_response_time]

    print("means of v1:\n", v1_means, "\n")
    print("means of v2:\n", v2_means, "\n")
    return (v1_means, v2_means)

# compare versions


def do_version_compares():
    runs = 20
    time_end = 10000
    version_compares(runs, time_end)

# do_find_best_d()


do_version_compares()
